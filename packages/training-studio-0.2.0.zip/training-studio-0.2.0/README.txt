Training Studio 0.2.0

Run (Windows, Python 3.10+ and internet needed on the first run):
    training-management-server\studio.bat
then open http://127.0.0.1:8700 .  The first run creates backend\.venv and installs backend\requirements.txt.
Unzip to a SHORT folder (e.g. C:\studio): Windows limits paths to 260 characters and the install fails in deep folders.
(Alternative: set STUDIO_VENV=C:\studio-venv before running studio.bat.)

What is inside: the web app, the built frontend, and a light copy of the project data (results, dataset metadata, model configs,
train logs, small robot files).
Not inside: dataset videos/parquet, model weights, the training environment (env\python.exe), Isaac Sim. So on this machine the
app browses data and manages robots/models; it cannot train or play episodes unless you add them.

To use your own data: copy datasets\lerobot\<name>, outputs\<run> and results\ into training-management-server\ (same layout as the
project), then press "Quét lại dữ liệu" on the Overview page. To train, also install the training environment so that
training-management-server\env\python.exe exists.

The app has no login: keep it on 127.0.0.1 (default). Options: STUDIO_HOST, STUDIO_PORT, STUDIO_DB (see studio.bat).
See training-management-server\STUDIO.md for the full documentation.
