"""Paths for the studio backend. Everything is derived from this file's location (no hard-coded D:\\ paths)."""
import os
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
ROOT = BACKEND.parent                      # training-management-server/
REPO = ROOT.parent                         # My-Humanoid-Hand/
DESIGN = Path(os.environ.get("MHH_DESIGN_DIR", REPO / "design"))

DATASETS = ROOT / "datasets" / "lerobot"
OUTPUTS = ROOT / "outputs"
RESULTS = ROOT / "results"
LOGS = ROOT / "logs"
MODELS = ROOT / "models"
HUMANOID_JSON = ROOT / "scripts" / "data" / "humanoid.json"

DB_PATH = Path(os.environ.get("STUDIO_DB", BACKEND / "data" / "studio.db"))
FRONTEND_DIST = ROOT / "frontend" / "dist"
