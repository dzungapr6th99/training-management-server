@echo off
REM Training Studio. Starts the web app; browse to http://127.0.0.1:8700
REM   First run on a new machine: creates a Python venv and installs backend\requirements.txt (needs Python 3.10+ and internet).
REM   Options (environment variables):
REM     STUDIO_HOST  default 127.0.0.1      STUDIO_PORT  default 8700      STUDIO_DB  database file
REM     STUDIO_VENV  where the venv lives (default backend\.venv). Windows limits paths to 260 characters and pyarrow has deep
REM                  folders: if the install fails with "No such file or directory ... pyarrow", unzip to a SHORT folder
REM                  (e.g. C:\studio) or set STUDIO_VENV=C:\studio-venv.
REM   The app has NO login. Keep STUDIO_HOST=127.0.0.1 unless the network is trusted (it can start training jobs and delete entries).
setlocal
for %%I in ("%~dp0.") do set "ROOT=%%~fI"
cd /d "%ROOT%\backend" || exit /b 1
if "%STUDIO_VENV%"=="" set "STUDIO_VENV=%ROOT%\backend\.venv"
if not exist "%STUDIO_VENV%\Scripts\python.exe" (
  echo [studio] first run: creating the Python environment in %STUDIO_VENV%
  where py >nul 2>nul && (py -3 -m venv "%STUDIO_VENV%") || (python -m venv "%STUDIO_VENV%")
  if errorlevel 1 ( echo [studio] could not create the venv: install Python 3.10 or newer from python.org and retry & exit /b 1 )
  "%STUDIO_VENV%\Scripts\python.exe" -m pip install -q -r requirements.txt
  if errorlevel 1 (
    echo [studio] pip install failed: check the internet connection, or the folder path is too long ^(see STUDIO_VENV above^)
    rmdir /s /q "%STUDIO_VENV%" 2>nul
    exit /b 1
  )
)
if "%STUDIO_HOST%"=="" set "STUDIO_HOST=127.0.0.1"
if "%STUDIO_PORT%"=="" set "STUDIO_PORT=8700"
echo [studio] http://%STUDIO_HOST%:%STUDIO_PORT%   (Ctrl+C to stop)
"%STUDIO_VENV%\Scripts\python.exe" -m uvicorn app.main:app --host %STUDIO_HOST% --port %STUDIO_PORT%
